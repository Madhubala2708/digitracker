function HrEmployee () {
    return (
        <>
        
        </>
    )
}

export default HrEmployee ;