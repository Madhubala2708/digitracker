import Permissions from "../Permissions";
import SideNav from "../SideNav";
import { TopNav } from "../TopNav";
import Department from "./Index";

export default function DepartmentTable () {
    return (
        <>
            {/* <TopNav />
            <Permissions /> */}
            {/* <SideNav /> */}
            <Department />
        </>
    )
}