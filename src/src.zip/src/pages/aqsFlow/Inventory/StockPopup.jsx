import React, { useState, useEffect } from "react";
import "../../../styles/components/css/aqsStyles/StockPopup.css";
import { useDispatch, useSelector } from "react-redux";
import {
  fetchVendors,
  fetchProjectTeam,
  fetchMaterialNames,
} from "../../../store/slice/Aqs/inventorySlice";

const StockPopup = ({
  title,
  onClose,
  onSubmit,
  data,
  projectId,
  projectName,
}) => {
  const dispatch = useDispatch();

  const vendors = useSelector((state) => state.inventory.vendors || []);
  const projectTeam = useSelector((state) => state.inventory.projectTeam || []);
  const materialNames = useSelector(
    (state) => state.inventory.materialNames || []
  );

  const [status, setStatus] = useState("Approved");
  const [receivedDate, setReceivedDate] = useState(null);
  const [project, setProject] = useState(projectName || "");
  const [grnNo, setGrnNo] = useState("");
  const [itemName, setItemName] = useState("");
  const [quantity, setQuantity] = useState("");
  const [vendor, setVendor] = useState("");
  const [receivedBy, setReceivedBy] = useState("");

  const isInward = title?.toLowerCase().includes("inward");
  const isOutward = title?.toLowerCase().includes("outward");
  const isViewMode = title?.toLowerCase().includes("view");

  const user = JSON.parse(localStorage.getItem("userData"));
  const loggedEmpId = user?.empId || "";
  const loggedUserName = user?.fullName || user?.firstName || "User";

  useEffect(() => {
    if (projectId) {
      dispatch(fetchProjectTeam(projectId));
      dispatch(fetchVendors());
      dispatch(fetchMaterialNames(projectId));
    }
  }, [projectId, dispatch]);

  useEffect(() => {
    if (data) {
      setGrnNo(data.grn || data.issueNo || "");
      setProject(data.projectName || projectName);
      setItemName(data.itemName || data.item || "");
      setQuantity(
        data.quantityReceived ??
          data.receivedQuantity ??
          data.issuedQuantity ??
          data.quantity ??
          ""
      );

      const date = data.dateReceived || data.dateIssued;
      if (date) setReceivedDate(new Date(date));
      setStatus(data.status || "Approved");

      if (isOutward) {
        setVendor(data.issuedToId || loggedEmpId);
        setReceivedBy(data.requestedById || "");
      } else {
        setVendor(data.vendorId || "");
        setReceivedBy(data.receivedById || loggedEmpId);
      }
    } else {
      const random = Math.floor(1000 + Math.random() * 9000);
      setGrnNo(isInward ? `GRN-${random}` : `ISS-${random}`);
      setProject(projectName);
      setReceivedDate(new Date());
      if (isInward) setReceivedBy(loggedEmpId);
      if (isOutward) setVendor(loggedEmpId);
    }
  }, [data, projectName, isInward, isOutward, loggedEmpId]);

  const handleSubmit = () => {
    if (isViewMode) return onClose();
    if (!itemName || !quantity || (!receivedBy && isOutward)) {
      alert("Please fill all required fields.");
      return;
    }

    const formattedDate = receivedDate ? receivedDate.toISOString() : "";

    const payload = isInward
      ? {
          projectId,
          grn: grnNo,
          itemName,
          vendorId: vendor,
          quantityReceived: Number(quantity),
          dateReceived: formattedDate,
          receivedById: receivedBy,
          status,
        }
      : {
          projectId,
          issueNo: grnNo,
          itemName,
          requestedById: receivedBy,
          issuedToId: vendor,
          issuedQuantity: Number(quantity),
          dateIssued: formattedDate,
          status,
        };

    onSubmit(payload);
  };

  const renderMaterialOptions = () => {
    if (!materialNames.length) return null;

    return materialNames.map((m, idx) => {
      const label =
        m.materialName ||
        m.itemName ||
        m.name ||
        m.value ||
        (typeof m === "string" ? m : "");
      return (
        <option key={idx} value={label}>
          {label}
        </option>
      );
    });
  };

  return (
    <div className="popup-overlay">
      <div className="popup-box">
        <div className="popup-header">
          <h4>{title}</h4>
          <button className="close-btn" onClick={onClose}>
            ×
          </button>
        </div>

        <form className="popup-form" onSubmit={(e) => e.preventDefault()}>
          {/* Row 1 */}
          <div className="form-row">
            <div className="form-group">
              <label>{isInward ? "Project" : "Issued From"}</label>
              <input type="text" value={project} readOnly />
            </div>
            <div className="form-group">
              <label>{isInward ? "GRN No." : "Issue No."}</label>
              <input type="text" value={grnNo} readOnly />
            </div>
          </div>

          {/* Row 2 */}
          <div className="form-row">
            <div className="form-group">
              <label>Item Name *</label>
              <select
                value={itemName}
                onChange={(e) => setItemName(e.target.value)}
                disabled={isViewMode}
              >
                <option value="">Select Item</option>
                {renderMaterialOptions()}
              </select>
            </div>

            <div className="form-group">
              <label>Quantity *</label>
              <input
                type="text"
                value={quantity}
                placeholder="Enter Qty"
                onChange={(e) => setQuantity(e.target.value)}
                disabled={isViewMode}
              />
            </div>
          </div>

          {/* Row 3 */}
          <div className="form-row">
            <div className="form-group">
              <label>{isInward ? "Vendor" : "Issued To"} *</label>

              {isInward ? (
                <select
                  value={vendor}
                  onChange={(e) => setVendor(e.target.value)}
                  disabled={isViewMode}
                >
                  <option value="">Select Vendor</option>
                  {vendors.map((v) => (
                    <option key={v.vendorId} value={v.vendorId}>
                      {v.vendorName}
                    </option>
                  ))}
                </select>
              ) : (
                <input type="text" value={loggedUserName} readOnly />
              )}
            </div>

            <div className="form-group">
              <label>{isInward ? "Received Date" : "Issued Date"} *</label>
              <input
                type="date"
                value={receivedDate?.toISOString().split("T")[0] || ""}
                onChange={(e) => setReceivedDate(new Date(e.target.value))}
                disabled={isViewMode}
              />
            </div>
          </div>

          {/* Row 4 */}
          <div className="form-row">
            <div className="form-group">
              <label>{isInward ? "Received By" : "Requested By"} *</label>
              {isInward ? (
                <input type="text" readOnly value={loggedUserName} />
              ) : (
                <select
                  value={receivedBy}
                  onChange={(e) => setReceivedBy(e.target.value)}
                  disabled={isViewMode}
                >
                  <option value="">Select Engineer</option>
                  {projectTeam.map((t) => (
                    <option key={t.empId} value={t.empId}>
                      {t.fullName}
                    </option>
                  ))}
                </select>
              )}
            </div>

            <div className="form-group">
              <label>Status</label>
              <select
                value={status}
                onChange={(e) => setStatus(e.target.value)}
                disabled={isViewMode}
              >
                <option value="Approved">Approved</option>
                <option value="Pending">Pending</option>
                <option value="Rejected">Rejected</option>
              </select>
            </div>
          </div>

          {/* Submit */}
          <div className="form-actions d-flex justify-content-center">
            <button className="update-btn" type="button" onClick={handleSubmit}>
              {isViewMode ? "Close" : "Update"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};

export default StockPopup;