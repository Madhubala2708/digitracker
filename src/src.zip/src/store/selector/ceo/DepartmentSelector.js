export const selectDepartmentsDetails = (state) => state.departments.data;
export const selectSelectedDepartmentEmployees = (state) => state.departments.selectedDepartmentEmployees;
