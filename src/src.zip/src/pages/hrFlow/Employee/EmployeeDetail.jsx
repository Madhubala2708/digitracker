function HrEmployeeDetails () {
    return (
        <>
        
        </>
    )
}

export default HrEmployeeDetails ;