function HrAddEmployee () {
    return (
        <>
        
        </>
    )
}

export default HrAddEmployee ;