import './spinner.styles.scss';

const Spinner = () => (
  <div className='spinner'>
    <div className=""></div>
  </div>
);

export default Spinner;
