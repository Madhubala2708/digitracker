import React, { useEffect, useState } from "react";
import { Gantt, ViewMode } from "gantt-task-react";
import "gantt-task-react/dist/index.css";

const GanttChart = ({ milestone, onClose }) => {
  const [ganttTasks, setGanttTasks] = useState([]);

  // 🔵 Calculate Auto Progress
  const calculateProgress = (start, end, isFinished = false) => {
    if (isFinished) return 100;

    const s = new Date(start);
    const e = new Date(end);
    const today = new Date();

    if (today <= s) return 0;
    if (today >= e) return 100;

    return Math.round(((today - s) / (e - s)) * 100);
  };

  // 🔵 Convert Milestones & Tasks into Gantt Format
  useEffect(() => {
    if (!Array.isArray(milestone) || milestone.length === 0) {
      setGanttTasks([]);
      return;
    }

    let formatted = [];

    milestone.forEach((m) => {
      if (!m.milestone_start_date || !m.milestone_end_date) return;

      // 🔶 Milestone Bar
      formatted.push({
        id: `M-${m.milestone_id}`,
        name: m.milestone_name,
        start: new Date(m.milestone_start_date),
        end: new Date(m.milestone_end_date),
        type: "project",
        progress: calculateProgress(m.milestone_start_date, m.milestone_end_date),
        hideChildren: false
      });

      // 🔷 Tasks under this milestone
      if (Array.isArray(m.tasks)) {
        m.tasks.forEach((t) => {
          if (!t.start_date || !t.planned_end_date) return;

          formatted.push({
            id: `T-${t.task_code}`,
            name: t.task_name || "(No Name)",
            start: new Date(t.start_date),
            end: new Date(t.planned_end_date),
            type: "task",
            project: `M-${m.milestone_id}`,
            progress: calculateProgress(
              t.start_date,
              t.planned_end_date,
              !!t.finished_date
            ),
            isDisabled: false
          });
        });
      }
    });

    setGanttTasks(formatted);
  }, [milestone]);

  if (!ganttTasks.length)
    return (
      <div className="text-center p-3">
        <h5>No Gantt data available</h5>
        <button
          className="btn btn-secondary mt-3"
          onClick={onClose}
        >
          Back
        </button>
      </div>
    );

  return (
    <div style={{ padding: "20px" }}>
      {/* 🔙 Back Button */}
      <button
        className="btn btn-dark mb-3"
        onClick={onClose}
      >
        ← Back
      </button>

      {/* 📊 Gantt Chart */}
      <Gantt
        tasks={ganttTasks}
        viewMode={ViewMode.Day}
        listCellWidth={""}     // hides left-side name cell if empty
        columnWidth={65}
      />
    </div>
  );
};

export default GanttChart;
